public class Rekening04 {
    String noRekening;
    String nama;
    String namaIbu;
    String Phone;
    String Email;

    Rekening04(String noRekening, String nama, String namaIbu, String Phone, String Email) {
        this.noRekening = noRekening;
        this.nama = nama;
        this.namaIbu = namaIbu;
        this.Phone = Phone;
        this.Email = Email;
    }

     // Metode untuk menampilkan informasi rekening
    public void displayInfo() {
        System.out.println("No Rekening: " + noRekening);
        System.out.println("Nama: " + nama);
        System.out.println("Nama Ibu: " + namaIbu);
        System.out.println("Phone: " + Phone);
        System.out.println("Email: " + Email);
    }
}