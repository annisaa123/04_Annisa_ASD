public class Transaksi04 {
    double saldo;
    double saldoAwal;
    double saldoAkhir;
    String tanggalTransaksi;
    String type;

    // Konstruktor Transaksi
    public Transaksi04(double saldo, double saldoAwal, double saldoAkhir, String tanggalTransaksi, String type) {
        this.saldo = saldo;
        this.saldoAwal = saldoAwal;
        this.saldoAkhir = saldoAkhir;
        this.tanggalTransaksi = tanggalTransaksi;
        this.type = type;
    }

    // Metode untuk menampilkan informasi transaksi
    public void displayInfo() {
        System.out.println("Saldo: " + saldo);
        System.out.println("Saldo Awal: " + saldoAwal);
        System.out.println("Saldo Akhir: " + saldoAkhir);
        System.out.println("Tanggal Transaksi: " + tanggalTransaksi);
        System.out.println("Type: " + type);
    }
}